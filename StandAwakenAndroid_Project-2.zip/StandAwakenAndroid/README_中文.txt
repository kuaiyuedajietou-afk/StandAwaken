替身觉醒：星尘竞技场 - Android 工程

重要：这是 Android Studio 工程源码，不是已经编译好的 APK。
当前运行环境没有 Android SDK / Gradle 构建环境，因此无法在这里生成可安装 APK。

生成 APK：
1. 电脑安装 Android Studio（建议最新版）。
2. 解压本工程 ZIP。
3. Android Studio 选择 Open，打开 StandAwakenAndroid 文件夹。
4. 等待 Gradle Sync 完成；首次构建需要网络下载 Android Gradle Plugin 和 AndroidX WebKit。
5. 菜单 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. APK 通常生成在 app/build/outputs/apk/debug/app-debug.apk。
7. 将 app-debug.apk 传到安卓手机，允许从该来源安装后即可安装。

注意：
- 游戏使用 WebView 封装现有 HTML 游戏。
- 游戏中的 Three.js 从 jsDelivr CDN 加载，因此首次运行需要网络。
- 当前版本为第一版原型，不是正式商店发行包。
